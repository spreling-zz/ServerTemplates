<?php
  Echo "Jah hoor hij werkt. Nu moet je nog shit toevoegen :P";

?>
